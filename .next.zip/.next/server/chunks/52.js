"use strict";
exports.id = 52;
exports.ids = [52];
exports.modules = {

/***/ 7052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "FC": () => (/* reexport */ arrow_right),
  "EH": () => (/* reexport */ ic_art),
  "Oh": () => (/* reexport */ binance),
  "tb": () => (/* reexport */ blockchain),
  "JG": () => (/* reexport */ copy),
  "i2": () => (/* reexport */ created),
  "I_": () => (/* reexport */ desc_about),
  "ZR": () => (/* reexport */ film),
  "H6": () => (/* reexport */ game),
  "rz": () => (/* reexport */ listing),
  "sS": () => (/* reexport */ mask),
  "g2": () => (/* reexport */ music),
  "U9": () => (/* reexport */ pen_edit),
  "yJ": () => (/* reexport */ sale),
  "ir": () => (/* reexport */ small_dp),
  "PI": () => (/* reexport */ star_cup),
  "qK": () => (/* reexport */ trending)
});

// UNUSED EXPORTS: discord, github, instagram, marketplace, telegram, twitter

;// CONCATENATED MODULE: ./assets/icons/arrow-right.svg
/* harmony default export */ const arrow_right = ({"src":"/_next/static/media/arrow-right.d71d62c5.svg","height":15,"width":9});
;// CONCATENATED MODULE: ./assets/icons/star-cup.svg
/* harmony default export */ const star_cup = ({"src":"/_next/static/media/star-cup.761d60cc.svg","height":30,"width":29});
;// CONCATENATED MODULE: ./assets/icons/mask.svg
/* harmony default export */ const mask = ({"src":"/_next/static/media/mask.dc6fae12.svg","height":40,"width":40});
;// CONCATENATED MODULE: ./assets/icons/ic-art.svg
/* harmony default export */ const ic_art = ({"src":"/_next/static/media/ic-art.c5147e11.svg","height":29,"width":29});
;// CONCATENATED MODULE: ./assets/icons/game.svg
/* harmony default export */ const game = ({"src":"/_next/static/media/game.900e3e88.svg","height":23,"width":33});
;// CONCATENATED MODULE: ./assets/icons/film.svg
/* harmony default export */ const film = ({"src":"/_next/static/media/film.a0c56262.svg","height":30,"width":30});
;// CONCATENATED MODULE: ./assets/icons/music.svg
/* harmony default export */ const music = ({"src":"/_next/static/media/music.fcb8c7fb.svg","height":31,"width":31});
;// CONCATENATED MODULE: ./assets/icons/small-dp.svg
/* harmony default export */ const small_dp = ({"src":"/_next/static/media/small-dp.87203413.svg","height":30,"width":30});
;// CONCATENATED MODULE: ./assets/icons/pen-edit.svg
/* harmony default export */ const pen_edit = ({"src":"/_next/static/media/pen-edit.54194795.svg","height":13,"width":12});
;// CONCATENATED MODULE: ./assets/icons/binance.svg
/* harmony default export */ const binance = ({"src":"/_next/static/media/binance.da1afd7b.svg","height":28,"width":28});
;// CONCATENATED MODULE: ./assets/icons/desc-about.svg
/* harmony default export */ const desc_about = ({"src":"/_next/static/media/desc-about.cdd4a459.svg","height":30,"width":30});
;// CONCATENATED MODULE: ./assets/icons/blockchain.svg
/* harmony default export */ const blockchain = ({"src":"/_next/static/media/blockchain.55bc17c7.svg","height":26,"width":25});
;// CONCATENATED MODULE: ./assets/icons/copy.svg
/* harmony default export */ const copy = ({"src":"/_next/static/media/copy.9a224458.svg","height":14,"width":14});
;// CONCATENATED MODULE: ./assets/icons/trending.svg
/* harmony default export */ const trending = ({"src":"/_next/static/media/trending.de55543e.svg","height":25,"width":25});
;// CONCATENATED MODULE: ./assets/icons/listing.svg
/* harmony default export */ const listing = ({"src":"/_next/static/media/listing.26e494ab.svg","height":16,"width":16});
;// CONCATENATED MODULE: ./assets/icons/sale.svg
/* harmony default export */ const sale = ({"src":"/_next/static/media/sale.fffcc6f9.svg","height":18,"width":18});
;// CONCATENATED MODULE: ./assets/icons/created.svg
/* harmony default export */ const created = ({"src":"/_next/static/media/created.037b5a77.svg","height":17,"width":17});
;// CONCATENATED MODULE: ./assets/icons/twitter.svg
/* harmony default export */ const twitter = ({"src":"/_next/static/media/twitter.7f2c58f6.svg","height":14,"width":16});
;// CONCATENATED MODULE: ./assets/icons/instagram.svg
/* harmony default export */ const instagram = ({"src":"/_next/static/media/instagram.2438e788.svg","height":18,"width":18});
;// CONCATENATED MODULE: ./assets/icons/discord.svg
/* harmony default export */ const discord = ({"src":"/_next/static/media/discord.1b8b1ff9.svg","height":17,"width":20});
;// CONCATENATED MODULE: ./assets/icons/github.svg
/* harmony default export */ const github = ({"src":"/_next/static/media/github.ac7d1c21.svg","height":25,"width":24});
;// CONCATENATED MODULE: ./assets/icons/telegram.svg
/* harmony default export */ const telegram = ({"src":"/_next/static/media/telegram.57168bd4.svg","height":23,"width":22});
;// CONCATENATED MODULE: ./assets/icons/marketplace.svg
/* harmony default export */ const marketplace = ({"src":"/_next/static/media/marketplace.510b59cb.svg","height":17,"width":17});
;// CONCATENATED MODULE: ./assets/icons/index.js























 // import {
 //   } from '../assets/icons';


/***/ })

};
;