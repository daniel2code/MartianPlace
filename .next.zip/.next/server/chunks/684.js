"use strict";
exports.id = 684;
exports.ids = [684];
exports.modules = {

/***/ 774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "GZ": () => (/* reexport */ character),
  "sX": () => (/* reexport */ path0),
  "Dh": () => (/* reexport */ space)
});

;// CONCATENATED MODULE: ./assets/images/path0.svg
/* harmony default export */ const path0 = ({"src":"/_next/static/media/path0.2c45dc9f.svg","height":348,"width":319});
;// CONCATENATED MODULE: ./assets/images/character.png
/* harmony default export */ const character = ({"src":"/_next/static/media/character.08c01243.png","height":251,"width":240,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAflBMVEWraE9ec5o0ICRBJCNPMUFaOUKUnbsvJjKNTER1QV5zUnuESluHT1NuPT8eITKRoebMxeDZup+FmcN5h5rSqo2XXE1lNTRNMDN+QkFqOkN7RE9NNkvQkWBdZJqLQUmHT2dqTXpbR2eDhtKIXn2Iv/+lnaqptcl1aHNSQmmVu+PLlCQCAAAAGXRSTlP+/uDg4P3+/t/+/eD93fz+/v7+/v7////++YhwuAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAEhJREFUCJkFwQUCgCAABLBDBcQuGuz8/wfd0HAysFFz8Hje1/do+LbrJ0YUtv2QeKOFX2UIUjjQogKoMFCLU9rOBnWZpUmW5z+1zASwfcUS2wAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/images/space.svg
/* harmony default export */ const space = ({"src":"/_next/static/media/space.e4e78d72.svg","height":618,"width":627});
;// CONCATENATED MODULE: ./assets/images/index.js
// images






/***/ }),

/***/ 684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ NftCard),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7052);
/* harmony import */ var _assets_images__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(774);





const Card = ({ img , charName , description , moreDetail  })=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "border border-light-grey-2 bg-line-light md:p-6 p-2 rounded-xl mt-8 w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "font-light mb-3",
                        children: "Game"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        src: img || _assets_images__WEBPACK_IMPORTED_MODULE_4__/* .character */ .GZ,
                        height: 500,
                        width: 500
                    })
                }),
                charName && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-3 mb-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold text-pink",
                        children: charName || 'Cyberpunkez'
                    })
                }),
                description && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-3",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "font-light",
                        children: [
                            description || 'In Night City, a mercenary known as V navigates a dystopian',
                            "society."
                        ]
                    })
                }),
                moreDetail && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-light text-light-grey-1",
                        children: moreDetail && '9 available NFT’s'
                    })
                })
            ]
        })
    }));
};
const NftCard = ({ img  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "border border-light-grey-2 bg-line-light md:p-6 p-2 rounded-xl mt-8 w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "font-light mb-3",
                        children: "Game"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        src: img || _assets_images__WEBPACK_IMPORTED_MODULE_4__/* .character */ .GZ,
                        height: 500,
                        width: 500
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "font-light",
                                    children: "Cats in Heaven"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "font-light",
                                    children: "Price"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    children: "Picasso Kong #1"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                            src: _assets_icons__WEBPACK_IMPORTED_MODULE_3__/* .binance */ .Oh
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "ml-2",
                                            children: "4.25"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);


/***/ })

};
;