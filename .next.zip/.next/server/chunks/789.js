exports.id = 789;
exports.ids = [789];
exports.modules = {

/***/ 3676:
/***/ ((module) => {

// Exports
module.exports = {
	"dark-1": "#222529",
	"dark-2": "#282c32",
	"dark-3": "#1c1e20",
	"mid-grey-4": "#515f73",
	"mid-grey-2": "#5c6a7e",
	"light-grey-1": "#7f97a1",
	"purple-primary": "#b182fb",
	"purple-secondary": "#d16cfc",
	"pink": "#f952fe",
	"icon": "AlertModal_icon__0Oa_s",
	"grid": "AlertModal_grid__pSzc1",
	"expand": "AlertModal_expand__mGk3W",
	"profile": "AlertModal_profile__VEa_p",
	"settings": "AlertModal_settings__fVVCe",
	"website": "AlertModal_website__3B8Ds",
	"twitter": "AlertModal_twitter__9og9v",
	"telegram": "AlertModal_telegram__0CvdW",
	"discord": "AlertModal_discord__UkCzE",
	"arrow-up": "AlertModal_arrow-up__yhF_6",
	"arrow-down": "AlertModal_arrow-down__cwEdW",
	"activity": "AlertModal_activity__lqQU0",
	"love": "AlertModal_love__Vm7w8",
	"love-grey": "AlertModal_love-grey__hxRsH",
	"ethereum": "AlertModal_ethereum__QdrHi",
	"backgroundContainer": "AlertModal_backgroundContainer__wa7sn",
	"modalBox": "AlertModal_modalBox__AL3DS",
	"imgBox": "AlertModal_imgBox__I6A4P",
	"modalTitle": "AlertModal_modalTitle___3RdP",
	"text": "AlertModal_text__h1EYs"
};


/***/ }),

/***/ 5233:
/***/ ((module) => {

// Exports
module.exports = {
	"dark-1": "#222529",
	"dark-2": "#282c32",
	"dark-3": "#1c1e20",
	"mid-grey-4": "#515f73",
	"mid-grey-2": "#5c6a7e",
	"light-grey-1": "#7f97a1",
	"purple-primary": "#b182fb",
	"purple-secondary": "#d16cfc",
	"pink": "#f952fe",
	"icon": "Input_icon__o903m",
	"grid": "Input_grid__jmm76",
	"expand": "Input_expand__zPyhU",
	"profile": "Input_profile__q7dSJ",
	"settings": "Input_settings___t8gc",
	"website": "Input_website__YaBRI",
	"twitter": "Input_twitter__A6cmt",
	"telegram": "Input_telegram__VP7M1",
	"discord": "Input_discord__Tv6fj",
	"arrow-up": "Input_arrow-up__A4dBz",
	"arrow-down": "Input_arrow-down___X3hj",
	"activity": "Input_activity__C_g_9",
	"love": "Input_love__eicd_",
	"love-grey": "Input_love-grey__4G8tX",
	"ethereum": "Input_ethereum__sqd9r",
	"inputcontainer": "Input_inputcontainer__47SAh",
	"fieldInputContainer": "Input_fieldInputContainer___SKgV"
};


/***/ }),

/***/ 5005:
/***/ ((module) => {

// Exports
module.exports = {
	"dark-1": "#222529",
	"dark-2": "#282c32",
	"dark-3": "#1c1e20",
	"mid-grey-4": "#515f73",
	"mid-grey-2": "#5c6a7e",
	"light-grey-1": "#7f97a1",
	"purple-primary": "#b182fb",
	"purple-secondary": "#d16cfc",
	"pink": "#f952fe",
	"icon": "Layout_icon__nsn8A",
	"grid": "Layout_grid__SdCGW",
	"expand": "Layout_expand__Wuk4q",
	"profile": "Layout_profile__HtC9T",
	"settings": "Layout_settings__AN3N0",
	"website": "Layout_website___FYuA",
	"twitter": "Layout_twitter__Qmf0F",
	"telegram": "Layout_telegram__w7X4t",
	"discord": "Layout_discord__sh8KS",
	"arrow-up": "Layout_arrow-up__9kRVi",
	"arrow-down": "Layout_arrow-down__lHeZF",
	"activity": "Layout_activity__5dnG7",
	"love": "Layout_love__09kKa",
	"love-grey": "Layout_love-grey__zNIq_",
	"ethereum": "Layout_ethereum__5JA64",
	"container": "Layout_container__z4qWC",
	"content": "Layout_content__9Lmpp",
	"main": "Layout_main__fbfOy",
	"hero": "Layout_hero__nrFAe",
	"footerWrapper": "Layout_footerWrapper__dq_8u",
	"footer": "Layout_footer__bKkxe",
	"iconsBox": "Layout_iconsBox__4fEPr",
	"textBox": "Layout_textBox__lsctj"
};


/***/ }),

/***/ 3249:
/***/ ((module) => {

// Exports
module.exports = {
	"dark-1": "#222529",
	"dark-2": "#282c32",
	"dark-3": "#1c1e20",
	"mid-grey-4": "#515f73",
	"mid-grey-2": "#5c6a7e",
	"light-grey-1": "#7f97a1",
	"purple-primary": "#b182fb",
	"purple-secondary": "#d16cfc",
	"pink": "#f952fe",
	"icon": "Modal_icon__KFrYx",
	"grid": "Modal_grid__V_Vhq",
	"expand": "Modal_expand__oqcom",
	"profile": "Modal_profile__K3D3r",
	"settings": "Modal_settings__xzkvV",
	"website": "Modal_website__vj3o5",
	"twitter": "Modal_twitter__QRc6g",
	"telegram": "Modal_telegram__F_0Gf",
	"discord": "Modal_discord__E5AJ2",
	"arrow-up": "Modal_arrow-up__9ARtN",
	"arrow-down": "Modal_arrow-down__j25cG",
	"activity": "Modal_activity__5v_t6",
	"love": "Modal_love__B5kdh",
	"love-grey": "Modal_love-grey__mTNPV",
	"ethereum": "Modal_ethereum__xJz0M",
	"modal": "Modal_modal__fbvPB",
	"modalcontent": "Modal_modalcontent__PGIYP",
	"animatetop": "Modal_animatetop__xk5IB",
	"close": "Modal_close__gQ8Z2",
	"modalheader": "Modal_modalheader__dHaYc",
	"modalfooter": "Modal_modalfooter___nsyG"
};


/***/ }),

/***/ 8178:
/***/ ((module) => {

// Exports
module.exports = {
	"dark-1": "#222529",
	"dark-2": "#282c32",
	"dark-3": "#1c1e20",
	"mid-grey-4": "#515f73",
	"mid-grey-2": "#5c6a7e",
	"light-grey-1": "#7f97a1",
	"purple-primary": "#b182fb",
	"purple-secondary": "#d16cfc",
	"pink": "#f952fe",
	"icon": "Nav_icon__WK096",
	"grid": "Nav_grid___9gIa",
	"expand": "Nav_expand__K_2sI",
	"profile": "Nav_profile__dld4N",
	"settings": "Nav_settings__uBxbK",
	"website": "Nav_website__QzTpj",
	"twitter": "Nav_twitter__yWVl7",
	"telegram": "Nav_telegram__dMwc2",
	"discord": "Nav_discord__g8VLR",
	"arrow-up": "Nav_arrow-up__VxHQu",
	"arrow-down": "Nav_arrow-down__mTGKu",
	"activity": "Nav_activity__aoK2Z",
	"love": "Nav_love__i2jkv",
	"love-grey": "Nav_love-grey__plNN1",
	"ethereum": "Nav_ethereum__1ZXW7",
	"nav": "Nav_nav__bbBcN"
};


/***/ }),

/***/ 7050:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-down.2f925fef.svg","height":8,"width":14});

/***/ }),

/***/ 3314:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bnb.64875fc4.svg","height":16,"width":16});

/***/ }),

/***/ 6103:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/bshadow.06952b67.svg","height":498,"width":1600});

/***/ }),

/***/ 7345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/copy.b5856311.svg","height":12,"width":14});

/***/ }),

/***/ 7884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/eth.0f8fed1d.svg","height":48,"width":48});

/***/ }),

/***/ 8596:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ic-dots.75a88821.svg","height":16,"width":5});

/***/ }),

/***/ 5590:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/ic-user-2.573b15d4.svg","height":24,"width":19});

/***/ }),

/***/ 9079:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/insta2.ed6f4ae4.svg","height":33,"width":32});

/***/ }),

/***/ 4671:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/metamask.f7b31a7c.svg","height":32,"width":32});

/***/ }),

/***/ 6679:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/profileB.1369f61c.svg","height":315,"width":1600});

/***/ }),

/***/ 519:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/telegram2.f6784067.svg","height":33,"width":32});

/***/ }),

/***/ 7073:
/***/ (() => {

"use strict";
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/twitter2.9336acfb.svg","height":33,"width":32});

/***/ }),

/***/ 3240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/wallet.9e0c77b3.svg","height":26,"width":26});

/***/ }),

/***/ 5789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6850);
/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4299);
/* harmony import */ var _styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(5005);
/* harmony import */ var _styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _public_images_telegram2_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(519);
/* harmony import */ var _public_images_insta2_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9079);
/* harmony import */ var _public_images_twitter2_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7073);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2280);
/* harmony import */ var _public_images_metamask_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4671);
/* harmony import */ var _public_images_ic_user_2_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5590);
/* harmony import */ var _public_images_wallet_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3240);
/* harmony import */ var _public_images_copy_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7345);
/* harmony import */ var _public_images_bnb_svg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3314);
/* harmony import */ var _public_images_eth_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7884);
/* harmony import */ var _public_images_ic_dots_svg__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8596);
/* harmony import */ var _public_images_arrow_down_svg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7050);
/* harmony import */ var _public_images_profileB_svg__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6679);
/* harmony import */ var _public_images_bshadow_svg__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6103);
/* harmony import */ var _components_elements_Button__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9733);
/* harmony import */ var _store_slices_messageSlice__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(5739);
/* harmony import */ var _helpers_convertString__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(899);
/* harmony import */ var _wallet_connectors__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(8748);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(8519);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(web3__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _widgets_footer__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(2818);
/* harmony import */ var _components_elements_modal_Modal__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(6304);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Modal__WEBPACK_IMPORTED_MODULE_11__]);
_components_Modal__WEBPACK_IMPORTED_MODULE_11__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];
































// declare const window: Window &
//   typeof globalThis & {
//     ethereum: any;
//   };
// export const provider = new ethers.providers.Web3Provider(window.ethereum)
const Layout = ({ children  })=>{
    const { active , account , activate , deactivate  } = (0,_web3_react_core__WEBPACK_IMPORTED_MODULE_25__.useWeb3React)();
    const user = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.user
    );
    const message = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.message
    );
    const banner = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.banner
    );
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { 0: modalOpen , 1: setModalOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: alertOpen , 1: setAlertOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: showDisconnectBtn , 1: setShowDisconnectBtn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: switchNetworkBtn , 1: setSwitchNetworkBtn  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: usdBalance , 1: setUsdBalance  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    //
    const modalRef1 = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createRef();
    const modalRef2 = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createRef();
    const getUsdBal = ()=>{
        axios__WEBPACK_IMPORTED_MODULE_5___default().get('https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT').then((res)=>{
            // console.log("converted: $", parseFloat(res.data.price) * parseFloat(user.userBalance));
            // console.log("bnb price: ", res.data.price);
            setUsdBalance('$' + (0,_helpers_convertString__WEBPACK_IMPORTED_MODULE_30__/* .toFixed5 */ .l)((parseFloat(res.data.price) * parseFloat(user.userBalance)).toString()));
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (account && !user.userBalance) {
            getBalance(account);
        }
        if (user.userBalance && !usdBalance) {
            getUsdBal();
        }
        if (user && !user.userNetwork) {
            dispatch((0,_store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .switchNetwork */ .If)({
                userNetwork: 'BNB'
            }));
        }
        if (message.message) {
            // alert('message here: ', message.message);
            setAlertOpen(true);
        } else {
            setAlertOpen(false);
        }
    }, [
        modalOpen,
        user,
        message,
        active,
        account,
        usdBalance,
        banner
    ]);
    const toggleModal = ()=>setModalOpen(!modalOpen)
    ;
    const onWallet = ()=>{
        // if (modalOpen) {
        // }
        // else {
        toggleModal();
    // }
    };
    const connectWallet = async ()=>{
        try {
            await activate(_wallet_connectors__WEBPACK_IMPORTED_MODULE_24__/* .injected */ .L).then(()=>{
                //update dapp server get response token:
                dispatch((0,_store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .connect */ .$j)({
                    address: account,
                    userToken: 'fh'
                }));
            }).catch((er)=>console.log('activate err: ', er)
            );
        //after the promise...
        } catch (e) {
            console.log('connect error: ', e);
        }
    };
    const disconnectWallet = async ()=>{
        try {
            deactivate(_wallet_connectors__WEBPACK_IMPORTED_MODULE_24__/* .injected */ .L).then(()=>{
                dispatch((0,_store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .disconnect */ .zP)());
            });
        } catch (e) {
            console.log('disconnect error: ', e);
        }
    };
    const getBalance = async (address)=>{
        console.log('try get bal from ', address);
        window.ethereum.enable();
        if (typeof window.ethereum !== 'undefined') {
            console.log('window eth: ');
            // Instance web3 with the provided information
            // window.ethereum.enable()
            var web3 = new (web3__WEBPACK_IMPORTED_MODULE_26___default())(window.ethereum);
            try {
                // Request account access
                await window.ethereum.enable();
                await web3.eth.getBalance(address).then((bal)=>{
                    // console.log("user balance: ", ethers.utils.formatEther(bal))
                    dispatch((0,_store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .connect */ .$j)({
                        userBalance: ethers__WEBPACK_IMPORTED_MODULE_27__.ethers.utils.formatEther(bal)
                    }));
                });
            // then(console.log);
            // return true
            } catch (e) {
            // User denied access
            // return false
            }
        }
    };
    const copyWallet = ()=>{
        navigator.clipboard.writeText(account);
        dispatch((0,_store_slices_messageSlice__WEBPACK_IMPORTED_MODULE_23__/* .setMessage */ .PJ)({
            message: 'Copied!',
            description: '',
            buttons: JSON.stringify([
                {
                    name: "OK",
                    action: 'close',
                    fullcolor: true,
                    lg: false
                }, 
            ])
        }));
        toggleModal();
    };
    const dropMenu = ()=>{
        dispatch((0,_store_slices_messageSlice__WEBPACK_IMPORTED_MODULE_23__/* .setMessage */ .PJ)({
            message: 'Under implementation!',
            description: '',
            buttons: JSON.stringify([
                {
                    name: "OK",
                    action: 'close',
                    fullcolor: true,
                    lg: false
                }, 
            ])
        }));
    };
    const switchWNetwork = ()=>{
        //Disconnect wallet, connect to wallet, get response or reload the page and connect again
        var userN = user.userNetwork;
        if (userN == 'BNB') {
            userN = 'ETH';
        } else {
            userN = 'BNB';
        }
        dispatch((0,_store_slices_userSlice__WEBPACK_IMPORTED_MODULE_6__/* .switchNetwork */ .If)({
            userNetwork: userN
        }));
    // toggleModal();
    };
    const closeBtn = ()=>{
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                type: "button",
                id: "headerClose",
                buttonStyles: "mr-4 text-xl",
                onClick: toggleModal,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "font-bold text-input-text-light hover:text-purple-primary hover:pr-1",
                    children: "x"
                })
            })
        });
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: [
                    (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default().container)
                ].join(' '),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default().hero)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default().content),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Nav__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                onWallet: onWallet
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                                className: [
                                    (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default().main)
                                ].join(' '),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                    className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_31___default().section),
                                    children: children
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal",
                        children: active ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            ref: modalRef1,
                            headerCloseBtn: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                type: "button",
                                id: "headerClose",
                                buttonStyles: "mr-4 text-xl",
                                onClick: toggleModal,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "font-semibold text-input-text-light hover:text-purple-primary hover:pr-1",
                                    children: "x"
                                })
                            }),
                            setModalOpen: toggleModal,
                            modalOpen: modalOpen,
                            parentStyles: "md:w-80 w-full rounded-md border border-1 border-mid-grey-4 bg-[#222529]",
                            modalBody: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-row py-2 px-5 border-b border-b-1 border-b-mid-grey-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                src: _public_images_ic_user_2_svg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
                                                alt: 'user',
                                                width: 14,
                                                height: 14
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                className: "text-white ml-3 font-medium",
                                                children: `My Profile`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-row py-2 px-5 border-b border-b-1 border-b-mid-grey-4 justify-between",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                        src: _public_images_wallet_svg__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
                                                        alt: 'wallet',
                                                        width: 18,
                                                        height: 18
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                        className: "text-white ml-3 font-medium",
                                                        children: `My Wallet`
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                            type: "button",
                                                            id: "disconnectW",
                                                            buttonStyles: "text-purple-secondary mr-1 font-light hover:pr-1 pb-1 hover:underline decoration-purple-secondary",
                                                            onClick: disconnectWallet,
                                                            onMouseEnter: ()=>setShowDisconnectBtn(true)
                                                            ,
                                                            onMouseLeave: ()=>setShowDisconnectBtn(false)
                                                            ,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                                children: showDisconnectBtn ? `Disconnect` : (0,_helpers_convertString__WEBPACK_IMPORTED_MODULE_30__/* .shortWallet */ .C)(account)
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                            type: "button",
                                                            id: "copy",
                                                            buttonStyles: "hover:pl-1",
                                                            onClick: copyWallet,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                                src: _public_images_copy_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
                                                                alt: 'copy',
                                                                width: 15,
                                                                height: 15
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "text-center m-5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-input-text-light",
                                                children: "Total Balance"
                                            }),
                                            user.userBalance && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "font-bold text-white font-[20px]",
                                                children: `${(0,_helpers_convertString__WEBPACK_IMPORTED_MODULE_30__/* .toFixed5 */ .l)(user.userBalance)} BNB`
                                            }),
                                            usdBalance && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-input-text-light font-[17px]",
                                                children: usdBalance.toString()
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex flex-row py-2 px-5 border-t border-t-1 border-t-mid-grey-4 justify-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mb-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                type: "button",
                                                id: "switchN",
                                                buttonStyles: "float-right text-purple-secondary font-light hover:pr-1 pb-1 underline decoration-purple-secondary",
                                                onClick: ()=>{
                                                // switchWNetwork()
                                                },
                                                onMouseEnter: ()=>setSwitchNetworkBtn(true)
                                                ,
                                                onMouseLeave: ()=>setSwitchNetworkBtn(false)
                                                ,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-row",
                                                    children: [
                                                        switchNetworkBtn && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                            className: "self-center mr-1",
                                                            children: `Switch Network`
                                                        }),
                                                        user.userNetwork == 'BNB' ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                            src: _public_images_eth_svg__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
                                                            alt: 'eth',
                                                            width: 25,
                                                            height: 25
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                            src: _public_images_bnb_svg__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
                                                            alt: 'bnb',
                                                            width: 25,
                                                            height: 25
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            ref: modalRef2,
                            headerCloseBtn: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                type: "button",
                                id: "headerClose",
                                buttonStyles: "mr-2 text-xl",
                                onClick: toggleModal,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "font-semibold text-input-text-light hover:text-purple-primary hover:pr-1",
                                    children: "x"
                                })
                            }),
                            setModalOpen: toggleModal,
                            modalOpen: modalOpen,
                            title: "Connect Wallet",
                            titleStyles: "text-pink font-semibold justify-self-start",
                            footer: "How do I create a metamask wallet?",
                            footerStyles: "text-input-text-light justify-self-start",
                            parentStyles: "py-5 px-4 md:w-80 w-full rounded-md border border-1 border-mid-grey-4 bg-[#222529]",
                            modalBody: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row py-2 px-2 my-5 justify-between rounded border border-1 border-input-text-light",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                src: _public_images_metamask_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                                                alt: 'metamask',
                                                width: 20,
                                                height: 20
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                className: "text-white ml-2",
                                                children: `Metamask`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_Button__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                            type: "button",
                                            id: "connect",
                                            buttonStyles: "text-input-text-light hover:text-purple-primary hover:pr-1 hover:underline",
                                            onClick: connectWallet,
                                            label: "Connect"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    alertOpen ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "alert",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_elements_modal_Modal__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z, {
                            modalOpen: true,
                            modalTitle: message.message,
                            modalText: message.description,
                            closeAction: ()=>{
                                dispatch((0,_store_slices_messageSlice__WEBPACK_IMPORTED_MODULE_23__/* .clearMessage */ .c4)());
                                setAlertOpen(false);
                            },
                            btns: message.buttons,
                            size: message.size
                        })
                    }) : null
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

});

/***/ }),

/***/ 2280:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3249);
/* harmony import */ var _styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7269);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([reactstrap__WEBPACK_IMPORTED_MODULE_3__]);
reactstrap__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const Modal = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef(function Modal(props, ref) {
    const { id , setModalOpen , modalOpen , close , title , parentStyles , titleStyles , footerStyles , footer , modalBody , bodyStyles , headerCloseBtn , footerCloseBtn , headerBody ,  } = props;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(reactstrap__WEBPACK_IMPORTED_MODULE_3__.Modal, {
        ref: ref,
        id: id,
        toggle: setModalOpen,
        isOpen: modalOpen,
        className: parentStyles,
        children: [
            headerBody ? headerBody : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4___default().modalheader)} flex flex-row justify-between text-center`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        className: titleStyles,
                        children: title
                    }),
                    headerCloseBtn
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_3__.ModalBody, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `${(_styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4___default().modalbody)} ${bodyStyles}`,
                    children: modalBody
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(reactstrap__WEBPACK_IMPORTED_MODULE_3__.ModalFooter, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_styles_Modal_module_scss__WEBPACK_IMPORTED_MODULE_4___default().modalfooter)} flex flex-row justify-between`,
                    children: [
                        footerCloseBtn,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            className: footerStyles,
                            children: footer
                        })
                    ]
                })
            })
        ]
    }));
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Modal);

});

/***/ }),

/***/ 4299:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Nav)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./styles/Nav.module.scss
var Nav_module = __webpack_require__(8178);
var Nav_module_default = /*#__PURE__*/__webpack_require__.n(Nav_module);
;// CONCATENATED MODULE: ./components/elements/Logo.js


// import styles from '../../styles/Logo.module.scss'
const Logo = (props)=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "logo",
        children: props.image ? /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
            className: "image",
            src: props.image,
            alt: props.title,
            width: 35,
            height: 35
        }) : ''
    }));
};
/* harmony default export */ const elements_Logo = (Logo);

;// CONCATENATED MODULE: ./public/images/head.svg
/* harmony default export */ const head = ({"src":"/_next/static/media/head.3c0a079f.svg","height":348,"width":319});
;// CONCATENATED MODULE: ./public/images/avatar.svg
/* harmony default export */ const avatar = ({"src":"/_next/static/media/avatar.7da5fce2.svg","height":43,"width":40});
;// CONCATENATED MODULE: ./public/images/search.svg
/* harmony default export */ const search = ({"src":"/_next/static/media/search.991a3110.svg","height":18,"width":18});
// EXTERNAL MODULE: ./public/images/metamask.svg
var metamask = __webpack_require__(4671);
;// CONCATENATED MODULE: ./public/images/menu.svg
/* harmony default export */ const menu = ({"src":"/_next/static/media/menu.7330fbd0.svg","height":25,"width":26});
;// CONCATENATED MODULE: ./public/images/close.svg
/* harmony default export */ const images_close = ({"src":"/_next/static/media/close.7e22fc5b.svg","height":18,"width":18});
// EXTERNAL MODULE: ./components/elements/Button.js
var Button = __webpack_require__(9733);
// EXTERNAL MODULE: ./components/elements/Input.js
var Input = __webpack_require__(5857);
;// CONCATENATED MODULE: ./components/elements/Search.js




function Search() {
    const searchRef = useRef(null);
    const { 0: query1 , 1: setQuery  } = useState('');
    const { 0: active , 1: setActive  } = useState(false);
    const { 0: results , 1: setResults  } = useState([]);
    const searchEndpoint = (query)=>`/api/search?q=${query}`
    ;
    const onChange = useCallback((event)=>{
        const query = event.target.value;
        setQuery(query);
        if (query.length) {
            fetch(searchEndpoint(query)).then((res)=>res.json()
            ).then((res)=>{
                setResults(res.results);
            });
        } else {
            setResults([]);
        }
    }, []);
    const onFocus = useCallback(()=>{
        setActive(true);
        window.addEventListener('click', onClick);
    }, []);
    const onClick = useCallback((event)=>{
        if (searchRef.current && !searchRef.current.contains(event.target)) {
            setActive(false);
            window.removeEventListener('click', onClick);
        }
    }, []);
    return(/*#__PURE__*/ _jsxs("div", {
        className: styles.container,
        ref: searchRef,
        children: [
            /*#__PURE__*/ _jsx("input", {
                className: styles.search,
                onChange: onChange,
                onFocus: onFocus,
                placeholder: "Search posts",
                type: "text",
                value: query1
            }),
            active && results.length > 0 && /*#__PURE__*/ _jsx("ul", {
                className: styles.results,
                children: results.map(({ id , title  })=>/*#__PURE__*/ _jsx("li", {
                        className: styles.result,
                        children: /*#__PURE__*/ _jsx(Link, {
                            href: "/posts/[id]",
                            as: `/posts/${id}`,
                            children: /*#__PURE__*/ _jsx("a", {
                                children: title
                            })
                        })
                    }, id)
                )
            })
        ]
    }));
};

// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(8054);
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: ./config.js
var config = __webpack_require__(1838);
// EXTERNAL MODULE: ./nftABI.json
var nftABI = __webpack_require__(3072);
// EXTERNAL MODULE: ./marketABI.json
var marketABI = __webpack_require__(721);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
;// CONCATENATED MODULE: ./components/Nav.js






















const Nav = (props)=>{
    const { onWallet  } = props;
    const { active  } = (0,core_.useWeb3React)();
    const user = (0,external_react_redux_.useSelector)((state)=>state.user
    );
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { 0: nfts , 1: setNfts  } = (0,external_react_.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: openMenu , 1: setOpenMenu  } = (0,external_react_.useState)(false);
    const handleMobileMenu = ()=>{
        setOpenMenu(!openMenu);
    };
    const loadNFTs = async ()=>{
        setLoading(true);
        // const provider = new ethers.providers.JsonRpcProvider()
        // const tokenContract = new ethers.Contract(nftaddress, nftABI, provider)
        // const marketContract = new ethers.Contract(nftmarketaddress, marketABI, provider)
        //get signer
        window.ethereum.enable();
        const provider = new external_ethers_.ethers.providers.Web3Provider(window.ethereum);
        const signer = provider.getSigner();
        let marketContract = new external_ethers_.ethers.Contract(config/* nftmarketaddress */.A, marketABI, signer);
        //call market items from the market contract
        const data = await marketContract.fetchMarketItems();
        console.log("data: ", data);
        const items = await Promise.all(data.map(async (i)=>{
        // const tokenUri = await tokenContract.tokenUri(i.tokenid)
        // const meta = await axios.get(tokenUri)
        // let price = ethers.utils.formatUnits(i.price.toString(), 'ether')
        // let item = {
        //   price,
        //   tokenId: i.tokenId.toNumber(),
        //   seller: i.seller,
        //   owner: i.owner,
        //   image: meta.data.image,
        //   name: meta.data.name,
        //   description: meta.data.description,
        // }
        // return item
        }));
        setNfts(items);
        setLoading(false);
    };
    (0,external_react_.useEffect)(()=>{
    // loadNFTs()
    // console.log('userToken: ', user.userToken);
    }, [
        user,
        openMenu
    ]);
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
            className: `${(Nav_module_default()).nav} flex flex-wrap justify-between pt-3 lg:px-2`,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "m-2 lg:m-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(elements_Logo, {
                                        title: 'Moonshots',
                                        image: head
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                className: "text-[18px] cursor-default",
                                children: "Martianplace"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "|"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/about",
                                children: "About"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/discover",
                                children: "Discover"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/create",
                                children: "Create"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Input/* default */.Z, {
                                leftIcon: {
                                    src: search,
                                    alt: 'icon'
                                },
                                inputstyles: `shadow-inner lg:px-2 px-1 py-1 md:w-96 w-60 border-none
            focus:outline-none bg-color-search-input-bg)]`,
                                placeHolder: "Search digital collectables, art and more",
                                title: "Search",
                                onChange: ()=>{},
                                size: "xs",
                                parentstyles: `lg:ml-2 rounded-full border border-1 border-purple-primary bg-search-bg lg:pl-3 pl-2`
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hidden lg:block mt-2 mx-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                type: "button",
                                id: user.userToken ? 'btnconnected' : 'btnconnect',
                                buttonStyles: "lg:border lg:border-purple-primary lg:rounded-full lg:py-1.5 lg:px-2 lg:text-[14px] lg:hover:bg-background-gradient-btn",
                                onClick: onWallet,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "hidden lg:block",
                                    children: active ? 'Wallet connected' : 'Connect Wallet'
                                })
                            })
                        }),
                        active && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "lg:mt-2 lg:mx-3 mr-5",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>{},
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        className: "rounded-full hover:rounded-lg",
                                        src: avatar,
                                        alt: 'Profile',
                                        width: 35,
                                        height: 35
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "lg:hidden mr-2 mt-1",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                type: "button",
                                id: 'mobilemenu',
                                onClick: handleMobileMenu,
                                children: openMenu ? /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: images_close,
                                    alt: 'menu',
                                    width: 26,
                                    height: 26
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                    src: menu,
                                    alt: 'menu',
                                    width: 26,
                                    height: 26
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `${openMenu ? '' : 'hidden'} transition-all delay-150 duration-500 lg:hidden w-full inline-flex flex-grow w-auto py-2`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full items-start flex flex-col ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "border-b border-b-1 border-b-mid-grey-4 w-full px-3 py-4 text-white items-center justify-center hover:bg-green-600 hover:text-white ",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/about",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "border-b border-b-1 border-b-mid-grey-4 w-full px-3 py-4 text-white items-center justify-center hover:bg-green-600 hover:text-white",
                                    children: "About"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/discover",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "border-b border-b-1 border-b-mid-grey-4 w-full px-3 py-4 text-white items-center justify-center hover:bg-green-600 hover:text-white",
                                    children: "Discover"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/create",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "border-b border-b-1 border-b-mid-grey-4 w-full px-3 py-4 text-white items-center justify-center hover:bg-green-600 hover:text-white",
                                    children: "Create"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-9 w-full flex justify-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    type: "button",
                                    id: user.userToken ? 'btnconnected' : 'btnconnect',
                                    buttonStyles: "w-80 border border-purple-primary rounded-full py-1.5 px-2 text-[14px] bg-background-gradient-btn",
                                    onClick: onWallet,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "",
                                        children: active ? 'Wallet connected' : 'Connect Wallet'
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Nav = (Nav);


/***/ }),

/***/ 9733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export Button */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


function Button(props) {
    const { buttonStyles , id , label , name , title , type , leftIcon , rightIcon , rounded , onClick , children , onMouseEnter , onMouseLeave  } = props;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        type: type,
        id: id,
        title: title,
        className: buttonStyles,
        onClick: onClick,
        onMouseEnter: onMouseEnter,
        onMouseLeave: onMouseLeave,
        children: [
            label,
            children
        ]
    }));
// return (
//   <div className={['button', 'background-container', `background-container-${buttonStyle?.toLowerCase()}`].join(' ')}>
//     <button
//       type={type}
//       name={name}
//       id={id}
//       title={title}
//       className={[`${buttonStyle?.toLowerCase()}`, `${rounded ? 'circle' : ''}`].join(' ')}
//       onClick={onClick}>
//       {leftIcon ? <span className={['icon', leftIcon].join(' ')}></span> : ''}
//       {label ? <span className={'label'}>{label}</span> : ''}
//       {rightIcon ? <span className={['icon', rightIcon].join(' ')}></span> : ''}
//     </button>
//   </div>
// );
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 5857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5233);
/* harmony import */ var _styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);



const Input = (props)=>{
    const { id , title , placeHolder , type , leftIcon , rightIcon , parentstyles , inputstyles , label , labelstyles , min , postfix , fieldType , value , disabled , onChange  } = props;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: ``,
        children: [
            label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: labelstyles,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    children: label
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: fieldType == 'line' ? `${(_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().fieldInputContainer)} ${(_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().inputcontainer)} ${parentstyles}` : `${(_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().inputcontainer)} ${parentstyles}`,
                children: [
                    leftIcon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        src: leftIcon.src,
                        alt: leftIcon.alt,
                        width: 20,
                        height: 20,
                        className: (_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().icon)
                    }) : '',
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: inputstyles,
                        id: id,
                        type: type,
                        "aria-label": title,
                        placeholder: placeHolder,
                        min: min,
                        value: value,
                        disabled: disabled,
                        onChange: (ev)=>onChange(ev.target.value)
                    }),
                    rightIcon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                        src: rightIcon.src,
                        alt: rightIcon.alt,
                        width: 20,
                        height: 20,
                        className: (_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().icon)
                    }) : '',
                    postfix && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${(_styles_Input_module_scss__WEBPACK_IMPORTED_MODULE_2___default().icon)} text-mid-grey-2`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            children: postfix
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);


/***/ }),

/***/ 6304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Alert)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/AlertModal.module.scss
var AlertModal_module = __webpack_require__(3676);
var AlertModal_module_default = /*#__PURE__*/__webpack_require__.n(AlertModal_module);
;// CONCATENATED MODULE: ./assets/icons/close.svg
/* harmony default export */ const icons_close = ({"src":"/_next/static/media/close.e48e8df6.svg","height":24,"width":24});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
;// CONCATENATED MODULE: ./components/elements/modal/Modal.js






// btn2: accepts a boolean, indicating whether the button will be rendered on the UI
// btn1Text, btn2Text: pass the innerText of the button element
// modalTitle: the title or heading of the modal Box
// modalText: sub Text of the modal Box
// NB: position relative should be added to the parent contaniner, where Modal component will be rendered
// Example message dispatch
// dispatch(setMessage(
//   { message: 'NFT Created',
//   description: 'Congratulations your NFT has been successfully created on Martian Place.',
//   buttons: JSON.stringify([
//     {name: "View NFT", action: 'route', routepath: '/', fullcolor: true, lg: true},
//     {name: "Cancel", action: 'close', fullcolor: false, lg: false}
//   ])}))
// Example element: <Alert
//    modalOpen={true}
//    modalTitle={message.message}
//    modalText={message.description}
//    closeAction={() => setAlertOpen(false)}
//    btns={message.buttons}
//  />
function Alert({ modalTitle , modalText , closeAction , btns ,  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (AlertModal_module_default()).backgroundContainer,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `${(AlertModal_module_default()).modalBox}`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `flex justify-end ${(AlertModal_module_default()).imgBox}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        onClick: closeAction,
                        children: [
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: icons_close
                            }),
                            " "
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: (AlertModal_module_default()).modalTitle,
                    children: modalTitle
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: (AlertModal_module_default()).modalText,
                    children: modalText
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `${(AlertModal_module_default()).btnBox} flex mt-7`,
                    children: btns && JSON.parse(btns).map((btn, index)=>{
                        return(/*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: `h-10 ${btn.lg ? 'mr-3 md:w-80' : ''} rounded-full w-36 ${btn.fullcolor ? 'bg-background-gradient-btn' : 'border border-purple-primary'}`,
                            onClick: btn.action == "route" ? ()=>{
                                closeAction();
                                router_default().push(btn.routepath);
                            } : ()=>{
                                closeAction();
                            },
                            children: btn.name
                        }, index));
                    })
                })
            ]
        })
    }));
};


/***/ }),

/***/ 8748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ injected)
/* harmony export */ });
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8054);
/* harmony import */ var _web3_react_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web3_react_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6590);
/* harmony import */ var _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__);




const injected = new _web3_react_injected_connector__WEBPACK_IMPORTED_MODULE_2__.InjectedConnector({
    supportedNetworks: [
        1,
        56,
        97,
        3,
        4,
        5,
        42
    ]
});


/***/ }),

/***/ 2818:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _assets_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7052);





const Footer = ()=>{
    return(/*#__PURE__*/ _jsxs("footer", {
        className: "flex items-center justify-between text-white font-light py-6 md:mx-40 mx-3 border-t-2 border-light-grey-2",
        children: [
            /*#__PURE__*/ _jsx("div", {
                children: "@ 2022 Martianplace"
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        children: /*#__PURE__*/ _jsx(Link, {
                            href: "https://mobile.twitter.com/martianplace1",
                            children: /*#__PURE__*/ _jsx(Image, {
                                src: discord
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "ml-3",
                        children: /*#__PURE__*/ _jsx(Link, {
                            href: "https://discord.gg/mHdkMvHgrd",
                            children: /*#__PURE__*/ _jsx(Image, {
                                src: twitter
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "ml-3",
                        children: /*#__PURE__*/ _jsx(Link, {
                            href: "mailto:info@martianplace.io",
                            children: /*#__PURE__*/ _jsx(Image, {
                                src: marketplace
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "md:flex items-center hidden",
                children: [
                    /*#__PURE__*/ _jsx("p", {
                        children: "Privacy Policy"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "ml-3",
                        children: "Terms of Service"
                    })
                ]
            })
        ]
    }));
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Footer)));


/***/ }),

/***/ 1838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ nftaddress),
/* harmony export */   "A": () => (/* binding */ nftmarketaddress)
/* harmony export */ });
const nftaddress = "0x7D0E4792478b94EBA5554fc0C05F08CD9CaB6a6a";
const nftmarketaddress = "0xFF32a1e73a0000296C2e165F8b748E10800e7011";


/***/ }),

/***/ 899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ shortWallet),
/* harmony export */   "l": () => (/* binding */ toFixed5)
/* harmony export */ });
const shortWallet = (string)=>{
    return string.substr(0, 5) + ".." + string.slice(-5);
};
const toFixed5 = (string)=>{
    if (string) {
        var res = string.split('.');
        return res[0] + '.' + res[1].substr(0, 5);
    } else {
        return string;
    }
};


/***/ }),

/***/ 5739:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PJ": () => (/* binding */ setMessage),
/* harmony export */   "c4": () => (/* binding */ clearMessage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    message: null,
    size: null,
    description: null,
    buttons: []
};
const messageSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "message",
    initialState,
    reducers: {
        setMessage: (state, action)=>{
            return {
                message: action.payload.message,
                size: action.payload.size,
                description: action.payload.description,
                buttons: action.payload.buttons
            };
        },
        clearMessage: ()=>{
            return {
                message: null,
                size: null,
                description: null,
                buttons: null
            };
        }
    }
});
const { reducer , actions  } = messageSlice;
const { setMessage , clearMessage  } = actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducer);


/***/ }),

/***/ 6850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$j": () => (/* binding */ connect),
/* harmony export */   "zP": () => (/* binding */ disconnect),
/* harmony export */   "If": () => (/* binding */ switchNetwork),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export userSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    address: null,
    isconnected: false,
    userToken: null,
    userNetwork: null,
    userBalance: null
};
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: 'user',
    initialState,
    reducers: {
        connect: (state, action)=>{
            state.address = action.payload.address, state.isconnected = true, state.userToken = action.payload.userToken, state.userNetwork = action.payload.userNetwork, state.userBalance = action.payload.userBalance;
        },
        disconnect: (state)=>{
            state.address = null, state.isconnected = false, state.userToken = null, state.userNetwork = null, state.userBalance = null;
        },
        switchNetwork: (state, action)=>{
            state.userNetwork = action.payload.userNetwork;
        }
    }
});
const { connect , disconnect , switchNetwork  } = userSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);


/***/ }),

/***/ 721:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"itemId","type":"uint256"},{"indexed":true,"internalType":"address","name":"nftContract","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"},{"indexed":false,"internalType":"address","name":"seller","type":"address"},{"indexed":false,"internalType":"address","name":"owner","type":"address"},{"indexed":false,"internalType":"uint256","name":"price","type":"uint256"},{"indexed":false,"internalType":"bool","name":"sold","type":"bool"}],"name":"MarketItemCreated","type":"event"},{"inputs":[{"internalType":"address","name":"nftContract","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"uint256","name":"price","type":"uint256"}],"name":"createMarketItem","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"nftContract","type":"address"},{"internalType":"uint256","name":"itemId","type":"uint256"}],"name":"createMarketSale","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"address","name":"_caller","type":"address"}],"name":"fetchItemsCreated","outputs":[{"components":[{"internalType":"uint256","name":"itemId","type":"uint256"},{"internalType":"address","name":"nftContract","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"address payable","name":"seller","type":"address"},{"internalType":"address payable","name":"owner","type":"address"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"bool","name":"sold","type":"bool"}],"internalType":"struct NFTMarket.MarketItem[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"fetchMarketItems","outputs":[{"components":[{"internalType":"uint256","name":"itemId","type":"uint256"},{"internalType":"address","name":"nftContract","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"address payable","name":"seller","type":"address"},{"internalType":"address payable","name":"owner","type":"address"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"bool","name":"sold","type":"bool"}],"internalType":"struct NFTMarket.MarketItem[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_caller","type":"address"}],"name":"fetchMyNFTs","outputs":[{"components":[{"internalType":"uint256","name":"itemId","type":"uint256"},{"internalType":"address","name":"nftContract","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"address payable","name":"seller","type":"address"},{"internalType":"address payable","name":"owner","type":"address"},{"internalType":"uint256","name":"price","type":"uint256"},{"internalType":"bool","name":"sold","type":"bool"}],"internalType":"struct NFTMarket.MarketItem[]","name":"","type":"tuple[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getListingPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"newPrice","type":"uint256"}],"name":"setListingPrice","outputs":[],"stateMutability":"nonpayable","type":"function"}]');

/***/ }),

/***/ 3072:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('[{"inputs":[{"internalType":"address","name":"marketplaceAddress","type":"address"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"tokenURI","type":"string"}],"name":"createToken","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"}]');

/***/ })

};
;